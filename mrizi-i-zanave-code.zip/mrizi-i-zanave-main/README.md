# AgriSoft — Mrizi i Zanave

Platformë e integruar menaxhimi për biznesin real të agroturizmit **Mrizi i Zanave** në **Fishtë, Lezhë, Shqipëri**.
Projekt universitar për lëndën *Analizë dhe Dizajn Software*.

![Mrizi i Zanave](src/assets/exterior.jpg)

## ✨ Veçoritë

- **Landing page elegante** — hero me foto reale, galeri, hartë Google Maps, dëshmi
- **Sistem rezervimesh restoranti** — zgjedhja vizuale e tavolinave, parandalim dublikatash
- **Booking dhomash & bujtinash** — kartela, disponibilitet, çmime
- **Shitje produktesh lokale** — djathë, verë, mjaltë, vaj ulliri, reçele
- **Menaxhim inventari** — alarme stoku, furnitorë, kërkim
- **Panel admin** — statistika, grafikë (Recharts), menaxhim porosish
- **Autentikim me role** — Admin · Recepsionist · Kuzhinier · Magazinier · Klient
- **Llogari klienti** — profil, historik rezervimesh, anullim/modifikim
- **Responsive** — dizajn premium për desktop, tablet dhe mobile

## 🧰 Tech Stack

- **React 19** + **TypeScript**
- **TanStack Start** (router + SSR)
- **Tailwind CSS v4** me tokena semantike
- **Recharts** për analitikën
- **shadcn/ui** komponente
- **Lucide React** për ikona
- **Sonner** për toast notifications

## 🎨 Identiteti vizual

Paleta natyrore: jeshile pylli, krem, dru, terrakota.
Tipografi: **Fraunces** për titujt (display), **Inter** për tekstin.

## 🔑 Llogari demo

| Roli | Email | Fjalëkalimi |
|------|-------|-------------|
| Admin | admin@mrizi.al | admin |
| Recepsionist | recepsioni@mrizi.al | staff |
| Kuzhinier | kuzhina@mrizi.al | staff |
| Magazinier | magazina@mrizi.al | staff |
| Klient | klient@mrizi.al | klient |

## 🚀 Instalimi

```bash
bun install
bun dev
```

Vizito `http://localhost:5173`.

## 📁 Struktura

```
src/
├── assets/                # Fotot reale të Mrizi i Zanave
├── components/
│   ├── site/              # Navbar, Footer
│   └── ui/                # shadcn primitives
├── lib/
│   ├── auth.tsx           # Context i autentikimit (mock, localStorage)
│   └── mock-data.ts       # Të dhëna demo (dhoma, menu, produkte, inventar)
├── routes/
│   ├── __root.tsx         # Layout rrënjë
│   ├── index.tsx          # Landing page
│   ├── about.tsx, contact.tsx
│   ├── rooms.tsx          # Browse + booking dhomash
│   ├── restaurant.tsx     # Rezervime tavolinash
│   ├── shop.tsx           # Shitje produktesh
│   ├── login.tsx, register.tsx
│   ├── account.tsx        # Paneli i klientit
│   ├── dashboard.tsx      # Layout admin me sidebar
│   ├── dashboard.index.tsx        # Statistika + grafikë
│   ├── dashboard.reservations.tsx
│   ├── dashboard.rooms.tsx
│   ├── dashboard.restaurant.tsx
│   ├── dashboard.products.tsx
│   ├── dashboard.inventory.tsx
│   └── dashboard.reports.tsx
└── styles.css             # Design tokens (oklch)
```

## 📸 Fotografitë

Të gjitha imazhet janë foto reale nga **Mrizi i Zanave** dhe nga ambienti i fshatit Fishtë, Lezhë.
Nuk është përdorur asnjë imazh i gjeneruar nga AI.

## 📜 Licenca

Projekt akademik. Të gjitha të drejtat e markës *Mrizi i Zanave* i përkasin pronarit të biznesit.

---

Bërë me ❤️ në Shqipëri.
