// Mock auth context backed by localStorage. Demo-only — no real backend.
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Role = "admin" | "receptionist" | "restaurant" | "inventory" | "customer";

export type User = {
  id: string;
  name: string;
  email: string;
  role: Role;
};

type AuthCtx = {
  user: User | null;
  login: (email: string, password: string, role?: Role) => User;
  register: (name: string, email: string, password: string) => User;
  logout: () => void;
  updateProfile: (patch: Partial<User>) => void;
};

const Ctx = createContext<AuthCtx | null>(null);
const KEY = "agrisoft.user";

// Seeded demo accounts shown on the login screen
const demoAccounts: Record<string, { password: string; role: Role; name: string }> = {
  "admin@mrizi.al": { password: "admin", role: "admin", name: "Bardhi Admini" },
  "recepsioni@mrizi.al": { password: "staff", role: "receptionist", name: "Lira Recepsioni" },
  "kuzhina@mrizi.al": { password: "staff", role: "restaurant", name: "Genti Kuzhinieri" },
  "magazina@mrizi.al": { password: "staff", role: "inventory", name: "Ardit Magazinieri" },
  "klient@mrizi.al": { password: "klient", role: "customer", name: "Erjon Klienti" },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    try {
      const raw = typeof window !== "undefined" ? localStorage.getItem(KEY) : null;
      if (raw) setUser(JSON.parse(raw));
    } catch {}
  }, []);

  const persist = (u: User | null) => {
    setUser(u);
    if (typeof window === "undefined") return;
    if (u) localStorage.setItem(KEY, JSON.stringify(u));
    else localStorage.removeItem(KEY);
  };

  const login: AuthCtx["login"] = (email, password, role) => {
    const acc = demoAccounts[email.toLowerCase()];
    if (acc && acc.password === password) {
      const u: User = { id: email, name: acc.name, email, role: acc.role };
      persist(u);
      return u;
    }
    // Fallback — accept any credentials as customer (demo mode)
    const u: User = { id: email, name: email.split("@")[0], email, role: role ?? "customer" };
    persist(u);
    return u;
  };

  const register: AuthCtx["register"] = (name, email) => {
    const u: User = { id: email, name, email, role: "customer" };
    persist(u);
    return u;
  };

  const logout = () => persist(null);
  const updateProfile = (patch: Partial<User>) => user && persist({ ...user, ...patch });

  return <Ctx.Provider value={{ user, login, register, logout, updateProfile }}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth outside provider");
  return v;
}

export const demoLogins = Object.entries(demoAccounts).map(([email, a]) => ({
  email,
  password: a.password,
  role: a.role,
  name: a.name,
}));
