// Centralized mock data for AgriSoft (Mrizi i Zanave management platform)
import exterior from "@/assets/exterior.jpg";
import staff from "@/assets/staff.jpg";
import tableSunset from "@/assets/table-sunset.jpg";
import sign from "@/assets/sign.jpg";
import dish from "@/assets/dish.jpg";
import room from "@/assets/room.jpg";
import feast from "@/assets/feast.jpg";

export const photos = { exterior, staff, tableSunset, sign, dish, room, feast };

export type Room = {
  id: string;
  name: string;
  type: string;
  price: number;
  capacity: number;
  image: string;
  description: string;
  amenities: string[];
  available: boolean;
};

export const rooms: Room[] = [
  { id: "r1", name: "Dhoma e Maleve", type: "Suite", price: 120, capacity: 2, image: room, description: "Suite me pamje nga malet e Lezhës, dritare panoramike dhe trarë druri tradicionalë.", amenities: ["Pamje malore", "WiFi", "Mëngjes bio", "Oxhak"], available: true },
  { id: "r2", name: "Dhoma e Hardhive", type: "Standard", price: 85, capacity: 2, image: exterior, description: "Dhomë komode mbi vreshtën, e zhytur në qetësinë e fshatit Fishtë.", amenities: ["Pamje vreshtë", "WiFi", "Mëngjes bio"], available: true },
  { id: "r3", name: "Apartamenti Familjar", type: "Familjar", price: 180, capacity: 4, image: feast, description: "Apartament i gjerë për familje, me dy dhoma gjumi dhe ballkon.", amenities: ["2 dhoma", "Kuzhinë", "Ballkon", "WiFi"], available: true },
  { id: "r4", name: "Bujtina Tradicionale", type: "Bujtinë", price: 95, capacity: 3, image: tableSunset, description: "Bujtinë në stil tradicional shqiptar me materiale lokale.", amenities: ["Stil tradicional", "Oxhak", "Mëngjes bio"], available: false },
];

export type MenuItem = {
  id: string;
  name: string;
  category: string;
  price: number;
  image: string;
  description: string;
};

export const menu: MenuItem[] = [
  { id: "m1", name: "Tavë Kosi", category: "Pjata Kryesore", price: 9, image: dish, description: "Mish qengji me kos dhe oriz, gatuar në furrë balte." },
  { id: "m2", name: "Rosto me Përshesh", category: "Pjata Kryesore", price: 12, image: dish, description: "Rosto vendi me përshesh misri dhe djathë." },
  { id: "m3", name: "Fërgesë Tirane", category: "Antipasta", price: 6, image: feast, description: "Fërgesë me djathë, speca dhe domate." },
  { id: "m4", name: "Byrek me Spinaq", category: "Antipasta", price: 4, image: feast, description: "Byrek shtëpie me petë të hapura me dorë." },
  { id: "m5", name: "Verë e Kuqe Kallmet", category: "Pije", price: 18, image: tableSunset, description: "Verë vendi nga vreshtat e Lezhës." },
  { id: "m6", name: "Raki Rrushi", category: "Pije", price: 4, image: tableSunset, description: "Raki tradicionale, distiluar në fshat." },
  { id: "m7", name: "Bakllava", category: "Ëmbëlsira", price: 5, image: dish, description: "Bakllava me arra dhe mjaltë lokal." },
];

export type Product = {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  image: string;
  description: string;
};

export const products: Product[] = [
  { id: "p1", name: "Djathë i Bardhë Dele", category: "Bulmet", price: 14, stock: 32, image: feast, description: "Djathë artizanal nga qumështi i deleve të zonës." },
  { id: "p2", name: "Mjaltë Mali", category: "Mjaltë", price: 12, stock: 48, image: dish, description: "Mjaltë i pastër nga bletët e maleve të Lezhës." },
  { id: "p3", name: "Verë Kallmet", category: "Pije", price: 22, stock: 60, image: tableSunset, description: "Verë e kuqe vendi, e prodhuar tradicionalisht." },
  { id: "p4", name: "Vaj Ulliri Ekstra", category: "Vaj", price: 16, stock: 25, image: exterior, description: "Vaj ulliri i shtrydhur ftohtë nga ullishtet vendore." },
  { id: "p5", name: "Reçel Fiku", category: "Reçel", price: 7, stock: 18, image: feast, description: "Reçel fiku i punuar me dorë, pa konservantë." },
  { id: "p6", name: "Sallam Vendi", category: "Mish", price: 19, stock: 12, image: dish, description: "Sallam tradicional shqiptar, tymosur natyrshëm." },
];

export type InventoryItem = {
  id: string;
  name: string;
  unit: string;
  quantity: number;
  minStock: number;
  supplier: string;
};

export const inventory: InventoryItem[] = [
  { id: "i1", name: "Mish Qengji", unit: "kg", quantity: 24, minStock: 15, supplier: "Ferma Gjoni" },
  { id: "i2", name: "Qumësht Dele", unit: "litra", quantity: 8, minStock: 20, supplier: "Bujqit e Fishtës" },
  { id: "i3", name: "Miell Misri", unit: "kg", quantity: 60, minStock: 25, supplier: "Mulliri Lezhë" },
  { id: "i4", name: "Verë Kallmet", unit: "shishe", quantity: 120, minStock: 30, supplier: "Kantina Kallmet" },
  { id: "i5", name: "Vaj Ulliri", unit: "litra", quantity: 5, minStock: 10, supplier: "Ullishtet Fishtë" },
  { id: "i6", name: "Domate Bio", unit: "kg", quantity: 40, minStock: 15, supplier: "Kopshti Bio" },
];

export type Reservation = {
  id: string;
  customer: string;
  date: string;
  time: string;
  guests: number;
  notes?: string;
  status: "pending" | "confirmed" | "cancelled";
};

export const reservations: Reservation[] = [
  { id: "rs1", customer: "Familja Hoxha", date: "2026-05-18", time: "19:30", guests: 6, notes: "Tavolinë pranë dritares", status: "confirmed" },
  { id: "rs2", customer: "Andi Pali", date: "2026-05-18", time: "20:00", guests: 2, status: "pending" },
  { id: "rs3", customer: "Grupi Turistik IT", date: "2026-05-19", time: "13:00", guests: 14, notes: "Menu degustimi", status: "confirmed" },
  { id: "rs4", customer: "Erjon Marku", date: "2026-05-20", time: "21:00", guests: 4, status: "pending" },
];

export type Booking = {
  id: string;
  customer: string;
  roomId: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  status: "pending" | "confirmed" | "checked-in" | "checked-out";
};

export const bookings: Booking[] = [
  { id: "b1", customer: "Marco Rossi", roomId: "r1", checkIn: "2026-05-17", checkOut: "2026-05-19", guests: 2, status: "checked-in" },
  { id: "b2", customer: "Familja Kola", roomId: "r3", checkIn: "2026-05-20", checkOut: "2026-05-23", guests: 4, status: "confirmed" },
  { id: "b3", customer: "Anna Müller", roomId: "r2", checkIn: "2026-06-01", checkOut: "2026-06-04", guests: 2, status: "pending" },
];

export type Order = {
  id: string;
  table: string;
  items: { name: string; qty: number; price: number }[];
  status: "pending" | "preparing" | "served" | "paid";
  createdAt: string;
};

export const orders: Order[] = [
  { id: "o1", table: "Tav. 4", items: [{ name: "Tavë Kosi", qty: 2, price: 9 }, { name: "Verë Kallmet", qty: 1, price: 18 }], status: "preparing", createdAt: "2026-05-17T19:10" },
  { id: "o2", table: "Tav. 7", items: [{ name: "Byrek me Spinaq", qty: 3, price: 4 }, { name: "Raki Rrushi", qty: 2, price: 4 }], status: "served", createdAt: "2026-05-17T18:40" },
  { id: "o3", table: "Tav. 2", items: [{ name: "Rosto me Përshesh", qty: 4, price: 12 }], status: "paid", createdAt: "2026-05-17T13:20" },
  { id: "o4", table: "Tav. 9", items: [{ name: "Fërgesë Tirane", qty: 2, price: 6 }, { name: "Bakllava", qty: 2, price: 5 }], status: "pending", createdAt: "2026-05-17T20:05" },
];

export const revenueSeries = [
  { month: "Nën", revenue: 8400 },
  { month: "Dhj", revenue: 11200 },
  { month: "Jan", revenue: 9600 },
  { month: "Shk", revenue: 10400 },
  { month: "Mar", revenue: 13800 },
  { month: "Pri", revenue: 17200 },
  { month: "Maj", revenue: 19800 },
];

export const channelSeries = [
  { name: "Restorant", value: 52 },
  { name: "Hotel", value: 28 },
  { name: "Produkte", value: 20 },
];

export const testimonials = [
  { name: "Anna Müller", country: "Gjermani", quote: "Një përvojë e vërtetë e Shqipërisë rurale — ushqimi, njerëzit, peizazhi. Të paharrueshme." },
  { name: "Marco Rossi", country: "Itali", quote: "Mrizi i Zanave është një bizhuteri e agroturizmit ballkanik. Kthehemi sërish." },
  { name: "Elira Cami", country: "Shqipëri", quote: "Familja jonë e adhuroi vendin. Fëmijët mësuan për bujqësinë, ne shijuam darkën." },
];
