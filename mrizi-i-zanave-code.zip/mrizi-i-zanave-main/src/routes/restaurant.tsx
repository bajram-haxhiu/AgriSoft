import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { menu, photos } from "@/lib/mock-data";
import { useMemo, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/restaurant")({
  component: RestaurantPage,
  head: () => ({ meta: [{ title: "Rezervo Restorantin — Mrizi i Zanave" }, { name: "description", content: "Rezervo tavolinën tënde në restorantin e Mrizi i Zanave dhe shfleto menynë sezonale." }] }),
});

const TIMES = ["12:00", "12:30", "13:00", "13:30", "14:00", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30"];
const TABLES = Array.from({ length: 12 }, (_, i) => ({ id: i + 1, seats: i < 6 ? 4 : i < 10 ? 6 : 10, taken: [2, 5, 9].includes(i + 1) }));

function RestaurantPage() {
  const [date, setDate] = useState("");
  const [time, setTime] = useState("19:30");
  const [guests, setGuests] = useState(2);
  const [tableId, setTableId] = useState<number | null>(null);
  const [notes, setNotes] = useState("");
  const [category, setCategory] = useState<string>("Të gjitha");

  const cats = useMemo(() => ["Të gjitha", ...Array.from(new Set(menu.map((m) => m.category)))], []);
  const items = category === "Të gjitha" ? menu : menu.filter((m) => m.category === category);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date) return toast.error("Zgjidh datën");
    if (!tableId) return toast.error("Zgjidh një tavolinë");
    toast.success(`Rezervimi u konfirmua — Tav. ${tableId}, ${date} ${time}, ${guests} mysafirë`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <header className="relative isolate overflow-hidden">
        <img src={photos.feast} alt="Restoranti Mrizi i Zanave" className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="absolute inset-0 -z-10 bg-black/55" />
        <div className="mx-auto max-w-7xl px-4 py-24 text-white lg:px-8">
          <h1 className="font-display text-5xl font-semibold sm:text-6xl">Rezervo tavolinën tënde</h1>
          <p className="mt-3 max-w-2xl text-white/85">Një tryezë me histori — shijo kuzhinën sezonale të veriut shqiptar.</p>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-16 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.1fr_1fr]">
          <form onSubmit={submit} className="rounded-3xl border border-border bg-card p-6 shadow-sm">
            <h2 className="font-display text-2xl">Detajet e rezervimit</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              <Field label="Data"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" /></Field>
              <Field label="Ora">
                <select value={time} onChange={(e) => setTime(e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
                  {TIMES.map((t) => <option key={t}>{t}</option>)}
                </select>
              </Field>
              <Field label="Mysafirë"><input type="number" min={1} max={20} value={guests} onChange={(e) => setGuests(+e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" /></Field>
            </div>

            <div className="mt-6">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Zgjidh tavolinën</div>
              <div className="mt-3 grid grid-cols-4 gap-3 sm:grid-cols-6">
                {TABLES.map((t) => {
                  const tooSmall = t.seats < guests;
                  const disabled = t.taken || tooSmall;
                  const selected = tableId === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      disabled={disabled}
                      onClick={() => setTableId(t.id)}
                      className={`relative aspect-square rounded-2xl border-2 text-xs font-semibold transition ${
                        selected
                          ? "border-primary bg-primary text-primary-foreground"
                          : disabled
                          ? "cursor-not-allowed border-border bg-muted text-muted-foreground line-through"
                          : "border-border bg-card hover:border-primary"
                      }`}
                    >
                      T{t.id}
                      <span className="absolute bottom-1 left-0 right-0 text-[10px] font-normal opacity-70">{t.seats}p</span>
                    </button>
                  );
                })}
              </div>
              <div className="mt-3 flex gap-4 text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1"><i className="inline-block h-2 w-2 rounded-sm bg-muted" /> e zënë</span>
                <span className="flex items-center gap-1"><i className="inline-block h-2 w-2 rounded-sm bg-primary" /> e zgjedhur</span>
              </div>
            </div>

            <Field label="Kërkesa speciale"><textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" placeholder="Ditëlindje, alergji, vegjetariane..." /></Field>

            <button type="submit" className="mt-6 w-full rounded-full bg-primary py-3 text-sm font-semibold text-primary-foreground hover:opacity-90">Konfirmo Rezervimin</button>
          </form>

          <div>
            <h2 className="font-display text-3xl">Menyja sezonale</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {cats.map((c) => (
                <button key={c} onClick={() => setCategory(c)} className={`rounded-full px-4 py-1.5 text-xs font-semibold ${category === c ? "bg-primary text-primary-foreground" : "border border-border bg-card"}`}>{c}</button>
              ))}
            </div>
            <ul className="mt-6 divide-y divide-border rounded-2xl border border-border bg-card">
              {items.map((m) => (
                <li key={m.id} className="flex items-center gap-4 p-4">
                  <img src={m.image} alt={m.name} className="h-16 w-16 rounded-xl object-cover" />
                  <div className="flex-1">
                    <div className="flex items-baseline justify-between gap-3">
                      <div className="font-semibold">{m.name}</div>
                      <div className="font-display text-lg text-primary">€{m.price}</div>
                    </div>
                    <div className="text-xs text-muted-foreground">{m.description}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="mt-4 block first:mt-0">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}
