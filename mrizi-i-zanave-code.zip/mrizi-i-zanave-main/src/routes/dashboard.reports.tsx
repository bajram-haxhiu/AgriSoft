import { createFileRoute } from "@tanstack/react-router";
import { revenueSeries, products, inventory } from "@/lib/mock-data";
import { BarChart, Bar, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export const Route = createFileRoute("/dashboard/reports")({ component: Page });

function Page() {
  const best = [...products].sort((a, b) => b.price - a.price).slice(0, 5).map((p) => ({ name: p.name, shitje: Math.round(60 - p.price) }));
  const low = inventory.filter((i) => i.quantity < i.minStock);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-4">
        {[
          { l: "Të ardhura totale", v: `€${revenueSeries.reduce((s, r) => s + r.revenue, 0).toLocaleString()}` },
          { l: "Mesatare mujore", v: `€${Math.round(revenueSeries.reduce((s, r) => s + r.revenue, 0) / revenueSeries.length).toLocaleString()}` },
          { l: "Klientë të rinj", v: "27" },
          { l: "Stoku i ulët", v: low.length },
        ].map((s) => (
          <div key={s.l} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
            <div className="font-display text-2xl">{s.v}</div>
            <div className="text-xs text-muted-foreground">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <h3 className="font-display text-lg">Raporti i të ardhurave</h3>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={revenueSeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.88 0.02 80)" />
                <XAxis dataKey="month" /><YAxis /><Tooltip />
                <Line dataKey="revenue" stroke="oklch(0.42 0.09 145)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <h3 className="font-display text-lg">Produktet më të shitura</h3>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={best}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.88 0.02 80)" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} /><YAxis /><Tooltip />
                <Bar dataKey="shitje" fill="oklch(0.62 0.14 40)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h3 className="font-display text-lg">Artikujt me stok të ulët</h3>
        <table className="mt-4 w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr><th className="py-2">Artikull</th><th>Sasi</th><th>Min</th><th>Furnitor</th></tr>
          </thead>
          <tbody className="divide-y divide-border">
            {low.map((i) => (
              <tr key={i.id}><td className="py-3 font-medium">{i.name}</td><td className="text-destructive font-semibold">{i.quantity} {i.unit}</td><td>{i.minStock}</td><td className="text-muted-foreground">{i.supplier}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
