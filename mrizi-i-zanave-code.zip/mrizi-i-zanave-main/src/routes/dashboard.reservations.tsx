import { createFileRoute } from "@tanstack/react-router";
import { reservations as seed, type Reservation } from "@/lib/mock-data";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/reservations")({ component: Page });

function Page() {
  const [list, setList] = useState<Reservation[]>(seed);
  const [q, setQ] = useState("");
  const filtered = list.filter((r) => r.customer.toLowerCase().includes(q.toLowerCase()));
  const set = (id: string, status: Reservation["status"]) => { setList((l) => l.map((r) => r.id === id ? { ...r, status } : r)); toast.success(`Statusi: ${status}`); };

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-xl">Të gjitha rezervimet</h2>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Kërko klient..." className="rounded-lg border border-input bg-background px-3 py-2 text-sm" />
      </div>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr><th className="py-2">Klient</th><th>Data</th><th>Ora</th><th>Pers.</th><th>Shënime</th><th>Statusi</th><th></th></tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map((r) => (
              <tr key={r.id}>
                <td className="py-3 font-medium">{r.customer}</td>
                <td>{r.date}</td><td>{r.time}</td><td>{r.guests}</td>
                <td className="max-w-[200px] truncate text-muted-foreground">{r.notes ?? "—"}</td>
                <td><span className={`rounded-full px-2 py-1 text-[10px] font-semibold uppercase ${r.status === "confirmed" ? "bg-primary/10 text-primary" : r.status === "pending" ? "bg-accent/30 text-accent-foreground" : "bg-destructive/10 text-destructive"}`}>{r.status}</span></td>
                <td className="text-right">
                  <div className="flex justify-end gap-1">
                    <button onClick={() => set(r.id, "confirmed")} className="rounded-md border border-border px-2 py-1 text-xs hover:bg-secondary">Aprovo</button>
                    <button onClick={() => set(r.id, "cancelled")} className="rounded-md border border-border px-2 py-1 text-xs hover:bg-destructive hover:text-destructive-foreground">Anullo</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
