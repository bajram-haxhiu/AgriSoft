import { createFileRoute } from "@tanstack/react-router";
import { revenueSeries, channelSeries, reservations, bookings, orders, inventory } from "@/lib/mock-data";
import { CalendarCheck, BedDouble, UtensilsCrossed, ShoppingBasket, AlertTriangle, Wallet, Users } from "lucide-react";
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

export const Route = createFileRoute("/dashboard/")({ component: DashboardHome });

const COLORS = ["oklch(0.5 0.12 140)", "oklch(0.62 0.14 40)", "oklch(0.72 0.13 60)"];

function DashboardHome() {
  const lowStock = inventory.filter((i) => i.quantity < i.minStock).length;
  const totalRevenue = revenueSeries.reduce((s, r) => s + r.revenue, 0);

  const stats = [
    { label: "Rezervime Sot", value: reservations.length, icon: CalendarCheck, tone: "bg-primary/10 text-primary" },
    { label: "Bookingu Aktiv", value: bookings.filter((b) => b.status !== "checked-out").length, icon: BedDouble, tone: "bg-accent/20 text-accent-foreground" },
    { label: "Porosi Restoranti", value: orders.length, icon: UtensilsCrossed, tone: "bg-clay/20 text-clay" },
    { label: "Shitje Produktesh", value: 48, icon: ShoppingBasket, tone: "bg-leaf/20 text-leaf" },
    { label: "Alarme Stoku", value: lowStock, icon: AlertTriangle, tone: "bg-destructive/10 text-destructive" },
    { label: "Të Ardhura (7m)", value: `€${totalRevenue.toLocaleString()}`, icon: Wallet, tone: "bg-primary/10 text-primary" },
    { label: "Klientë të Rinj", value: 27, icon: Users, tone: "bg-accent/20 text-accent-foreground" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
            <div className={`mb-3 inline-grid h-9 w-9 place-items-center rounded-full ${s.tone}`}><s.icon className="h-4 w-4" /></div>
            <div className="font-display text-2xl">{s.value}</div>
            <div className="text-xs text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm lg:col-span-2">
          <h3 className="font-display text-lg">Të ardhurat mujore</h3>
          <div className="mt-4 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueSeries}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.5 0.12 140)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="oklch(0.5 0.12 140)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.88 0.02 80)" />
                <XAxis dataKey="month" stroke="oklch(0.48 0.02 70)" />
                <YAxis stroke="oklch(0.48 0.02 70)" />
                <Tooltip />
                <Area type="monotone" dataKey="revenue" stroke="oklch(0.42 0.09 145)" fill="url(#g1)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <h3 className="font-display text-lg">Shpërndarja</h3>
          <div className="mt-4 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={channelSeries} dataKey="value" nameKey="name" innerRadius={60} outerRadius={90}>
                  {channelSeries.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <h3 className="font-display text-lg">Rezervimet e fundit</h3>
          <ul className="mt-4 divide-y divide-border">
            {reservations.map((r) => (
              <li key={r.id} className="flex items-center justify-between py-3 text-sm">
                <div><div className="font-medium">{r.customer}</div><div className="text-xs text-muted-foreground">{r.date} · {r.time} · {r.guests} pers.</div></div>
                <span className={`rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase ${r.status === "confirmed" ? "bg-primary/10 text-primary" : r.status === "pending" ? "bg-accent/30 text-accent-foreground" : "bg-destructive/10 text-destructive"}`}>{r.status}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <h3 className="font-display text-lg">Porositë e ditës</h3>
          <div className="mt-4 h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={[{n:"Mëngj.",v:8},{n:"Drekë",v:24},{n:"Pasdite",v:11},{n:"Darkë",v:32}]}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.88 0.02 80)" />
                <XAxis dataKey="n" stroke="oklch(0.48 0.02 70)" /><YAxis stroke="oklch(0.48 0.02 70)" /><Tooltip />
                <Bar dataKey="v" fill="oklch(0.62 0.14 40)" radius={[8,8,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
