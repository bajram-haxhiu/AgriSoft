import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { photos } from "@/lib/mock-data";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      { title: "Rreth Nesh — Mrizi i Zanave" },
      { name: "description", content: "Historia e Mrizi i Zanave: agroturizmi që lindi në fshatin Fishtë, Lezhë." },
    ],
  }),
});

function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <header className="relative isolate overflow-hidden">
        <img src={photos.exterior} alt="Mrizi i Zanave" className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="absolute inset-0 -z-10 bg-black/55" />
        <div className="mx-auto max-w-7xl px-4 py-32 text-white lg:px-8">
          <h1 className="font-display text-5xl font-semibold sm:text-6xl">Rreth Mrizi i Zanave</h1>
          <p className="mt-4 max-w-2xl text-lg text-white/85">Një histori familjare, e rrënjosur në Fishtë të Lezhës që nga viti 2010.</p>
        </div>
      </header>
      <section className="mx-auto max-w-3xl px-4 py-20 lg:px-8">
        <p className="text-lg leading-relaxed text-foreground/85">
          Mrizi i Zanave nisi si një bujtinë e vogël ku familja Gjoka shërbente miqtë me atë që rritte vetë në tokë.
          Sot, është një rrjet i tërë i fermerëve të vegjël të zonës që furnizojnë kuzhinën dhe dyqanin tonë me djathë,
          mish, perime dhe verë.
        </p>
        <p className="mt-6 text-lg leading-relaxed text-foreground/85">
          Filozofia jonë është e thjeshtë: ngadalë, lokal, i ndershëm. Çdo pjatë rrëfen një histori — të bariut, të vreshtarit,
          të nënës që ende gatuan byrek me dorë.
        </p>
      </section>
      <Footer />
    </div>
  );
}
