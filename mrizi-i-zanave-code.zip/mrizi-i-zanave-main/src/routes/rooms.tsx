import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { rooms } from "@/lib/mock-data";
import { useState } from "react";
import { BedDouble, Users, Wifi } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/rooms")({
  component: RoomsPage,
  head: () => ({ meta: [{ title: "Dhomat & Bujtinat — Mrizi i Zanave" }, { name: "description", content: "Eksploro dhomat dhe bujtinat e Mrizi i Zanave në Fishtë, Lezhë." }] }),
});

function RoomsPage() {
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState(2);
  const { user } = useAuth();
  const nav = useNavigate();

  const book = (roomName: string) => {
    if (!checkIn || !checkOut) return toast.error("Zgjidh datat e qëndrimit");
    if (!user) { toast("Bëj hyrjen për të rezervuar"); nav({ to: "/login" }); return; }
    toast.success(`Rezervimi për ${roomName} u dërgua — ${checkIn} → ${checkOut}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-7xl px-4 py-16 lg:px-8">
        <h1 className="font-display text-5xl font-semibold">Dhomat & Bujtinat</h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">Zgjidh strehën tënde mes vreshtave dhe maleve të Lezhës.</p>

        <div className="mt-8 grid gap-4 rounded-3xl border border-border bg-card p-5 sm:grid-cols-3">
          <Field label="Check-in"><input type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" /></Field>
          <Field label="Check-out"><input type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" /></Field>
          <Field label="Mysafirë"><input type="number" min={1} max={10} value={guests} onChange={(e) => setGuests(+e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" /></Field>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {rooms.map((r) => (
            <article key={r.id} className="overflow-hidden rounded-3xl bg-card shadow-sm transition hover:shadow-xl">
              <div className="relative aspect-[4/3] overflow-hidden">
                <img src={r.image} alt={r.name} className="h-full w-full object-cover transition duration-700 hover:scale-105" />
                <span className={`absolute left-4 top-4 rounded-full px-3 py-1 text-xs font-semibold ${r.available ? "bg-primary text-primary-foreground" : "bg-destructive text-destructive-foreground"}`}>
                  {r.available ? "E disponueshme" : "E zënë"}
                </span>
              </div>
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground">{r.type}</div>
                    <h3 className="font-display text-2xl">{r.name}</h3>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-semibold text-primary">€{r.price}</div>
                    <div className="text-xs text-muted-foreground">/natë</div>
                  </div>
                </div>
                <p className="mt-3 text-sm text-muted-foreground">{r.description}</p>
                <div className="mt-4 flex flex-wrap gap-2 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {r.capacity} pers.</span>
                  <span className="inline-flex items-center gap-1"><BedDouble className="h-3.5 w-3.5" /> {r.type}</span>
                  <span className="inline-flex items-center gap-1"><Wifi className="h-3.5 w-3.5" /> WiFi</span>
                </div>
                <ul className="mt-3 flex flex-wrap gap-1.5">
                  {r.amenities.map((a) => <li key={a} className="rounded-full bg-secondary px-2.5 py-1 text-[11px]">{a}</li>)}
                </ul>
                <button
                  disabled={!r.available}
                  onClick={() => book(r.name)}
                  className="mt-5 w-full rounded-full bg-primary py-2.5 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
                >
                  Rezervo Tani
                </button>
              </div>
            </article>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}
