import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { products } from "@/lib/mock-data";
import { useMemo, useState } from "react";
import { ShoppingCart, Plus, Minus, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/shop")({
  component: ShopPage,
  head: () => ({ meta: [{ title: "Produkte Lokale — Mrizi i Zanave" }, { name: "description", content: "Djathë, verë, mjaltë dhe produkte tradicionale shqiptare direkt nga prodhuesit." }] }),
});

type CartItem = { id: string; qty: number };

function ShopPage() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [category, setCategory] = useState<string>("Të gjitha");
  const cats = useMemo(() => ["Të gjitha", ...Array.from(new Set(products.map((p) => p.category)))], []);
  const list = category === "Të gjitha" ? products : products.filter((p) => p.category === category);

  const add = (id: string) => setCart((c) => {
    const ex = c.find((x) => x.id === id);
    if (ex) return c.map((x) => x.id === id ? { ...x, qty: x.qty + 1 } : x);
    toast.success("U shtua në shportë");
    return [...c, { id, qty: 1 }];
  });
  const sub = (id: string) => setCart((c) => c.flatMap((x) => x.id === id ? (x.qty > 1 ? [{ ...x, qty: x.qty - 1 }] : []) : [x]));
  const remove = (id: string) => setCart((c) => c.filter((x) => x.id !== id));

  const total = cart.reduce((s, i) => {
    const p = products.find((p) => p.id === i.id)!;
    return s + p.price * i.qty;
  }, 0);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-7xl px-4 py-16 lg:px-8">
        <h1 className="font-display text-5xl font-semibold">Produkte Lokale</h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">Shijo në shtëpinë tënde aromat dhe shijet e Fishtës.</p>

        <div className="mt-8 flex flex-wrap gap-2">
          {cats.map((c) => (
            <button key={c} onClick={() => setCategory(c)} className={`rounded-full px-4 py-1.5 text-xs font-semibold ${category === c ? "bg-primary text-primary-foreground" : "border border-border bg-card"}`}>{c}</button>
          ))}
        </div>

        <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_360px]">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((p) => (
              <article key={p.id} className="overflow-hidden rounded-3xl bg-card shadow-sm transition hover:shadow-xl">
                <div className="aspect-square overflow-hidden"><img src={p.image} alt={p.name} className="h-full w-full object-cover transition duration-700 hover:scale-105" /></div>
                <div className="p-5">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">{p.category}</div>
                  <h3 className="font-display text-xl">{p.name}</h3>
                  <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{p.description}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <div className="font-display text-2xl text-primary">€{p.price}</div>
                    <button onClick={() => add(p.id)} className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground hover:opacity-90">
                      <ShoppingCart className="h-3.5 w-3.5" /> Shto
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <aside className="h-fit rounded-3xl border border-border bg-card p-6 shadow-sm lg:sticky lg:top-24">
            <h3 className="font-display text-xl">Shporta jote</h3>
            {cart.length === 0 ? (
              <p className="mt-4 text-sm text-muted-foreground">Shporta është bosh.</p>
            ) : (
              <>
                <ul className="mt-4 space-y-3">
                  {cart.map((i) => {
                    const p = products.find((p) => p.id === i.id)!;
                    return (
                      <li key={i.id} className="flex items-center gap-3">
                        <img src={p.image} alt={p.name} className="h-12 w-12 rounded-lg object-cover" />
                        <div className="flex-1 text-sm">
                          <div className="font-medium">{p.name}</div>
                          <div className="text-xs text-muted-foreground">€{p.price}</div>
                        </div>
                        <div className="flex items-center gap-1">
                          <button onClick={() => sub(p.id)} className="grid h-7 w-7 place-items-center rounded-full border border-border"><Minus className="h-3 w-3" /></button>
                          <span className="w-6 text-center text-sm">{i.qty}</span>
                          <button onClick={() => add(p.id)} className="grid h-7 w-7 place-items-center rounded-full border border-border"><Plus className="h-3 w-3" /></button>
                          <button onClick={() => remove(p.id)} className="ml-1 text-destructive"><Trash2 className="h-4 w-4" /></button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
                <div className="mt-6 flex items-baseline justify-between border-t border-border pt-4">
                  <span className="text-sm text-muted-foreground">Totali</span>
                  <span className="font-display text-2xl text-primary">€{total.toFixed(2)}</span>
                </div>
                <button onClick={() => { setCart([]); toast.success("Porosia u dërgua — do të kontaktoheni shumë shpejt."); }} className="mt-4 w-full rounded-full bg-primary py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
                  Përfundo Porosinë
                </button>
              </>
            )}
          </aside>
        </div>
      </main>
      <Footer />
    </div>
  );
}
