import { createFileRoute } from "@tanstack/react-router";
import { inventory as seed, type InventoryItem } from "@/lib/mock-data";
import { useState } from "react";
import { AlertTriangle, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/inventory")({ component: Page });

function Page() {
  const [list, setList] = useState<InventoryItem[]>(seed);
  const [q, setQ] = useState("");
  const filtered = list.filter((i) => i.name.toLowerCase().includes(q.toLowerCase()));
  const del = (id: string) => { setList((l) => l.filter((i) => i.id !== id)); toast.success("U fshi"); };

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-xl">Inventari</h2>
        <div className="flex gap-2">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Kërko..." className="rounded-lg border border-input bg-background px-3 py-2 text-sm" />
          <button onClick={() => toast("Forma e re (demo)")} className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground"><Plus className="h-3.5 w-3.5" /> Shto</button>
        </div>
      </div>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr><th className="py-2">Artikull</th><th>Sasia</th><th>Njësia</th><th>Min Stok</th><th>Furnitor</th><th>Statusi</th><th></th></tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map((i) => {
              const low = i.quantity < i.minStock;
              return (
                <tr key={i.id}>
                  <td className="py-3 font-medium">{i.name}</td>
                  <td>{i.quantity}</td><td>{i.unit}</td><td>{i.minStock}</td><td className="text-muted-foreground">{i.supplier}</td>
                  <td>
                    {low ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-destructive/10 px-2 py-1 text-[10px] font-semibold uppercase text-destructive"><AlertTriangle className="h-3 w-3" /> Stok i ulët</span>
                    ) : (
                      <span className="rounded-full bg-primary/10 px-2 py-1 text-[10px] font-semibold uppercase text-primary">OK</span>
                    )}
                  </td>
                  <td className="text-right">
                    <button onClick={() => del(i.id)} className="rounded-md border border-border p-1.5 hover:bg-destructive hover:text-destructive-foreground"><Trash2 className="h-3.5 w-3.5" /></button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
