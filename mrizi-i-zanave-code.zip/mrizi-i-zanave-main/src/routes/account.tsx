import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { reservations, bookings, rooms } from "@/lib/mock-data";
import { toast } from "sonner";
import { CalendarCheck, BedDouble, LogOut, User } from "lucide-react";

export const Route = createFileRoute("/account")({
  component: AccountPage,
  head: () => ({ meta: [{ title: "Llogaria ime — AgriSoft" }] }),
});

function AccountPage() {
  const { user, updateProfile, logout } = useAuth();
  const nav = useNavigate();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  useEffect(() => {
    if (!user) nav({ to: "/login" });
    else setName(user.name);
  }, [user, nav]);

  if (!user) return null;

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({ name });
    toast.success("Profili u përditësua");
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-12 lg:px-8">
        <div className="flex items-center gap-4">
          <div className="grid h-16 w-16 place-items-center rounded-full bg-primary text-2xl font-semibold text-primary-foreground">{user.name.charAt(0)}</div>
          <div>
            <h1 className="font-display text-3xl">Mirë se erdhe, {user.name}</h1>
            <p className="text-sm text-muted-foreground">{user.email}</p>
          </div>
          <button onClick={() => { logout(); nav({ to: "/" }); }} className="ml-auto inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-sm hover:bg-secondary"><LogOut className="h-4 w-4" /> Dilni</button>
        </div>

        <div className="mt-10 grid gap-6 lg:grid-cols-3">
          <form onSubmit={save} className="rounded-3xl border border-border bg-card p-6 shadow-sm">
            <h2 className="flex items-center gap-2 font-display text-xl"><User className="h-4 w-4" /> Profili</h2>
            <label className="mt-4 block"><span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Emri</span><input value={name} onChange={(e) => setName(e.target.value)} className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" /></label>
            <label className="mt-4 block"><span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Telefon</span><input value={phone} onChange={(e) => setPhone(e.target.value)} className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" placeholder="+355 ..." /></label>
            <button className="mt-6 w-full rounded-full bg-primary py-2.5 text-sm font-semibold text-primary-foreground">Ruaj</button>
          </form>

          <div className="rounded-3xl border border-border bg-card p-6 shadow-sm lg:col-span-2">
            <h2 className="flex items-center gap-2 font-display text-xl"><CalendarCheck className="h-4 w-4" /> Rezervimet e mia</h2>
            <ul className="mt-4 divide-y divide-border text-sm">
              {reservations.slice(0, 3).map((r) => (
                <li key={r.id} className="flex items-center justify-between py-3">
                  <div><div className="font-medium">Restorant · {r.date} {r.time}</div><div className="text-xs text-muted-foreground">{r.guests} persona</div></div>
                  <div className="flex gap-2">
                    <button onClick={() => toast("Modifikim (demo)")} className="rounded-md border border-border px-2 py-1 text-xs hover:bg-secondary">Modifiko</button>
                    <button onClick={() => toast.success("U anullua")} className="rounded-md border border-border px-2 py-1 text-xs hover:bg-destructive hover:text-destructive-foreground">Anullo</button>
                  </div>
                </li>
              ))}
            </ul>
            <h2 className="mt-8 flex items-center gap-2 font-display text-xl"><BedDouble className="h-4 w-4" /> Bookingu i dhomave</h2>
            <ul className="mt-4 divide-y divide-border text-sm">
              {bookings.map((b) => (
                <li key={b.id} className="flex items-center justify-between py-3">
                  <div><div className="font-medium">{rooms.find((r) => r.id === b.roomId)?.name}</div><div className="text-xs text-muted-foreground">{b.checkIn} → {b.checkOut} · {b.guests} pers.</div></div>
                  <span className="rounded-full bg-primary/10 px-2.5 py-1 text-[10px] font-semibold uppercase text-primary">{b.status}</span>
                </li>
              ))}
            </ul>
            <div className="mt-6 flex gap-2">
              <Link to="/restaurant" className="rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground">+ Rezervim i ri</Link>
              <Link to="/rooms" className="rounded-full border border-border px-4 py-2 text-xs font-semibold">+ Booking dhome</Link>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
