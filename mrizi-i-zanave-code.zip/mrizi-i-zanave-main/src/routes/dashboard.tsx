import { createFileRoute, Link, useNavigate, Outlet, useLocation } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth";
import {
  LayoutDashboard, CalendarCheck, BedDouble, UtensilsCrossed, ShoppingBasket,
  Boxes, BarChart3, LogOut, Leaf, Bell,
} from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  component: DashboardLayout,
  head: () => ({ meta: [{ title: "Paneli — AgriSoft" }] }),
});

type NavItem = { to: string; label: string; icon: typeof LayoutDashboard; exact?: boolean };
const nav: NavItem[] = [
  { to: "/dashboard", label: "Pamja e Përgjithshme", icon: LayoutDashboard, exact: true },
  { to: "/dashboard/reservations", label: "Rezervimet", icon: CalendarCheck },
  { to: "/dashboard/rooms", label: "Dhomat & Bookingu", icon: BedDouble },
  { to: "/dashboard/restaurant", label: "Restoranti", icon: UtensilsCrossed },
  { to: "/dashboard/products", label: "Produktet", icon: ShoppingBasket },
  { to: "/dashboard/inventory", label: "Inventari", icon: Boxes },
  { to: "/dashboard/reports", label: "Raportet", icon: BarChart3 },
];

function DashboardLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const loc = useLocation();

  useEffect(() => {
    if (!user) navigate({ to: "/login" });
    else if (user.role === "customer") navigate({ to: "/account" });
  }, [user, navigate]);

  if (!user || user.role === "customer") return null;

  return (
    <div className="flex min-h-screen bg-secondary/30">
      <aside className="hidden w-64 shrink-0 flex-col bg-sidebar text-sidebar-foreground lg:flex">
        <div className="flex items-center gap-2 px-6 py-6">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground"><Leaf className="h-4 w-4" /></span>
          <div>
            <div className="font-display text-lg">AgriSoft</div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-sidebar-foreground/60">Mrizi i Zanave</div>
          </div>
        </div>
        <nav className="flex-1 space-y-1 px-3">
          {nav.map((n) => (
            <Link key={n.to} to={n.to as any} activeOptions={{ exact: n.exact }}
              className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-sidebar-foreground/80 transition hover:bg-sidebar-accent hover:text-sidebar-foreground"
              activeProps={{ className: "bg-sidebar-accent text-sidebar-foreground" }}>
              <n.icon className="h-4 w-4" /> {n.label}
            </Link>
          ))}
        </nav>
        <div className="border-t border-sidebar-border p-4">
          <div className="mb-3 text-xs">
            <div className="font-semibold">{user.name}</div>
            <div className="text-sidebar-foreground/60 capitalize">{user.role}</div>
          </div>
          <button onClick={() => { logout(); navigate({ to: "/" }); }} className="inline-flex w-full items-center gap-2 rounded-lg border border-sidebar-border px-3 py-2 text-xs hover:bg-sidebar-accent">
            <LogOut className="h-3.5 w-3.5" /> Dilni
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-border bg-card px-6 py-4">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Paneli</div>
            <div className="font-display text-xl">{nav.find((n) => loc.pathname === n.to || (!n.exact && loc.pathname.startsWith(n.to)))?.label ?? ""}</div>
          </div>
          <div className="flex items-center gap-3">
            <button className="grid h-9 w-9 place-items-center rounded-full border border-border"><Bell className="h-4 w-4" /></button>
            <div className="grid h-9 w-9 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
              {user.name.charAt(0)}
            </div>
          </div>
        </header>
        <main className="flex-1 p-6 lg:p-8"><Outlet /></main>
      </div>
    </div>
  );
}
