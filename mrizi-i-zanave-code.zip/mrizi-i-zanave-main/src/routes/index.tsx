import { createFileRoute, Link } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { photos, testimonials } from "@/lib/mock-data";
import { ArrowRight, Leaf, UtensilsCrossed, BedDouble, ShoppingBasket, Star, MapPin, Phone, Mail } from "lucide-react";

export const Route = createFileRoute("/")({
  component: LandingPage,
  head: () => ({
    meta: [
      { title: "Mrizi i Zanave — Agroturizëm autentik shqiptar | Fishtë, Lezhë" },
      { name: "description", content: "Përjeto agroturizmin autentik shqiptar në Mrizi i Zanave — restorant, bujtina dhe produkte lokale në zemër të Fishtës, Lezhë." },
    ],
  }),
});

function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <About />
      <Experiences />
      <RestaurantSection />
      <RoomsSection />
      <Products />
      <Testimonials />
      <Gallery />
      <Contact />
      <Footer />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative isolate overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <img src={photos.tableSunset} alt="Tavolinë me ushqim tradicional në perëndim të diellit mbi vreshtat e Lezhës" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />
      </div>
      <div className="mx-auto max-w-7xl px-4 py-32 lg:px-8 lg:py-48">
        <span className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-4 py-1.5 text-xs uppercase tracking-[0.25em] text-white backdrop-blur">
          <Leaf className="h-3.5 w-3.5" /> Fishtë · Lezhë · Shqipëri
        </span>
        <h1 className="mt-6 max-w-3xl font-display text-5xl font-semibold text-white sm:text-6xl lg:text-7xl">
          Aty ku malet, vreshtat dhe miqësia takohen në një tavolinë.
        </h1>
        <p className="mt-6 max-w-xl text-lg text-white/85">
          Mrizi i Zanave — një udhëtim shqisor në kuzhinën, bujtinat dhe produktet e vërteta të fshatit shqiptar.
        </p>
        <div className="mt-10 flex flex-wrap gap-3">
          <Link to="/restaurant" className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition hover:opacity-90">
            Rezervo Restorantin <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/rooms" className="inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/10 px-6 py-3 text-sm font-semibold text-white backdrop-blur hover:bg-white/20">
            Eksploro Dhomat
          </Link>
          <Link to="/shop" className="inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/10 px-6 py-3 text-sm font-semibold text-white backdrop-blur hover:bg-white/20">
            Shiko Produktet
          </Link>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="mx-auto max-w-7xl px-4 py-24 lg:px-8">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <div>
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Rreth Nesh</span>
          <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Një histori e rrënjosur në tokën e Lezhës.</h2>
          <p className="mt-6 text-base leading-relaxed text-muted-foreground">
            Që nga viti 2010, familja Gjoka ka kthyer fshatin Fishtë në një destinacion ku traditat e tryezës shqiptare jetojnë çdo ditë.
            Çdo pjatë vjen nga ferma jonë dhe nga fermerë të vegjël të zonës — një ekonomi e ngrohtë, e ndershme dhe e ngadaltë.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-6">
            {[
              { n: "120+", l: "fermerë lokalë" },
              { n: "14", l: "vite tradite" },
              { n: "30k+", l: "miq të kthyer" },
            ].map((s) => (
              <div key={s.l}>
                <div className="font-display text-3xl text-primary">{s.n}</div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <img src={photos.exterior} alt="Pamje e jashtme e Mrizi i Zanave në Fishtë" className="aspect-[3/4] w-full rounded-2xl object-cover shadow-lg" />
          <img src={photos.staff} alt="Stafi i Mrizi i Zanave para vreshtave" className="mt-10 aspect-[3/4] w-full rounded-2xl object-cover shadow-lg" />
        </div>
      </div>
    </section>
  );
}

function Experiences() {
  const items = [
    { icon: UtensilsCrossed, title: "Restorant Tradicional", text: "Menu sezonale me përbërës nga ferma jonë dhe fermerët fqinjë.", img: photos.dish },
    { icon: BedDouble, title: "Bujtina & Dhoma", text: "Strehë e ngrohtë me trarë druri, oxhakë dhe pamje malore.", img: photos.room },
    { icon: ShoppingBasket, title: "Produkte Lokale", text: "Djathë, verë, mjaltë dhe reçele — direkt nga prodhuesit.", img: photos.feast },
  ];
  return (
    <section className="bg-secondary/40 py-24">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="max-w-2xl">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Përvoja</span>
          <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Tre mënyra për të jetuar Mrizin.</h2>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {items.map((it) => (
            <article key={it.title} className="group overflow-hidden rounded-3xl bg-card shadow-sm transition hover:shadow-xl">
              <div className="aspect-[4/3] overflow-hidden">
                <img src={it.img} alt={it.title} className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
              </div>
              <div className="p-6">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <it.icon className="h-5 w-5" />
                </span>
                <h3 className="mt-4 font-display text-2xl">{it.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{it.text}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function RestaurantSection() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-24 lg:px-8">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <img src={photos.feast} alt="Tavolinë me pjata tradicionale shqiptare" className="aspect-[4/3] w-full rounded-3xl object-cover shadow-lg" />
        <div>
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Restoranti</span>
          <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Një menu që ndryshon me stinët.</h2>
          <p className="mt-6 text-muted-foreground">
            Tavë Kosi, byrek shtëpie, rosto me përshesh, verë Kallmet — çdo pjatë është një kapitull i traditës veriore.
            Rezervo tavolinën tënde online dhe lër ne të kujdesemi për pjesën tjetër.
          </p>
          <Link to="/restaurant" className="mt-8 inline-flex rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:opacity-90">
            Rezervo Tavolinën
          </Link>
        </div>
      </div>
    </section>
  );
}

function RoomsSection() {
  return (
    <section className="bg-cream py-24">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="order-2 lg:order-1">
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Bujtina</span>
            <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Fli nën trarët e vjetër të Fishtës.</h2>
            <p className="mt-6 text-muted-foreground">
              Dhomat tona bashkojnë gurin, drurin dhe rehatinë moderne. Zgjohu me pamjen e vreshtave dhe një mëngjes të bërë në shtëpi.
            </p>
            <Link to="/rooms" className="mt-8 inline-flex rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:opacity-90">
              Eksploro Dhomat
            </Link>
          </div>
          <img src={photos.room} alt="Dhomë tradicionale me trarë druri dhe pamje malore" className="order-1 aspect-[4/3] w-full rounded-3xl object-cover shadow-lg lg:order-2" />
        </div>
      </div>
    </section>
  );
}

function Products() {
  const cats = ["Djathë", "Verë", "Mjaltë", "Vaj Ulliri", "Reçel", "Sallam"];
  return (
    <section className="mx-auto max-w-7xl px-4 py-24 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="max-w-2xl">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Produkte Lokale</span>
          <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Tradita në kavanoz.</h2>
        </div>
        <Link to="/shop" className="text-sm font-semibold text-primary hover:underline">Shiko të gjitha →</Link>
      </div>
      <div className="mt-10 grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {cats.map((c) => (
          <div key={c} className="rounded-2xl border border-border bg-card p-5 text-center transition hover:border-primary hover:shadow">
            <div className="font-display text-lg">{c}</div>
            <div className="mt-1 text-xs text-muted-foreground">Artizanale</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="bg-secondary/40 py-24">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="max-w-2xl">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Miqtë tanë</span>
          <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Çfarë thonë vizitorët.</h2>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <figure key={t.name} className="rounded-3xl bg-card p-8 shadow-sm">
              <div className="flex gap-0.5 text-accent">
                {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
              </div>
              <blockquote className="mt-4 text-base leading-relaxed">"{t.quote}"</blockquote>
              <figcaption className="mt-6 text-sm">
                <div className="font-semibold">{t.name}</div>
                <div className="text-muted-foreground">{t.country}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

function Gallery() {
  const imgs = [photos.exterior, photos.feast, photos.dish, photos.tableSunset, photos.room, photos.staff, photos.sign];
  return (
    <section className="mx-auto max-w-7xl px-4 py-24 lg:px-8">
      <span className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Galeria</span>
      <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Momente nga Mrizi.</h2>
      <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-4">
        {imgs.map((src, i) => (
          <img
            key={i}
            src={src}
            alt={`Galeri Mrizi i Zanave ${i + 1}`}
            className={`w-full rounded-2xl object-cover shadow-sm ${i % 3 === 0 ? "aspect-[3/4] row-span-2" : "aspect-square"}`}
          />
        ))}
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="bg-cream py-24">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 lg:grid-cols-2 lg:px-8">
        <div>
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Kontakt</span>
          <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Na vizitoni në Fishtë.</h2>
          <p className="mt-4 text-muted-foreground">Hapur çdo ditë. Rezervimi sugjerohet, veçanërisht në fundjavë.</p>
          <ul className="mt-8 space-y-4 text-sm">
            <li className="flex gap-3"><MapPin className="h-5 w-5 text-primary" /> Fishtë, Bashkia Lezhë, Shqipëri</li>
            <li className="flex gap-3"><Phone className="h-5 w-5 text-primary" /> +355 69 209 2298</li>
            <li className="flex gap-3"><Mail className="h-5 w-5 text-primary" /> info@mriziizanave.com</li>
          </ul>
        </div>
        <div className="overflow-hidden rounded-3xl shadow-lg">
          <iframe
            title="Mrizi i Zanave Fishtë Lezhë"
            src="https://www.google.com/maps?q=Mrizi+i+Zanave+Fishte+Lezhe&output=embed"
            className="h-[420px] w-full border-0"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  );
}
