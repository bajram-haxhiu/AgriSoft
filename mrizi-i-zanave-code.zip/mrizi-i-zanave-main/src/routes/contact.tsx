import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "Kontakt — Mrizi i Zanave Fishtë, Lezhë" },
      { name: "description", content: "Adresa, telefoni dhe harta për Mrizi i Zanave në Fishtë, Lezhë." },
    ],
  }),
});

function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-7xl px-4 py-16 lg:px-8">
        <h1 className="font-display text-5xl font-semibold">Kontakt</h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">Na shkruani për rezervime grupesh, evente apo bashkëpunime me fermerë lokalë.</p>
        <div className="mt-12 grid gap-10 lg:grid-cols-2">
          <div className="space-y-6">
            <Info icon={MapPin} label="Adresa" value="Fishtë, Bashkia Lezhë, Shqipëri" />
            <Info icon={Phone} label="Telefon" value="+355 69 209 2298" />
            <Info icon={Mail} label="Email" value="info@mriziizanave.com" />
            <Info icon={Clock} label="Orari" value="Çdo ditë · 11:00 – 23:00" />
          </div>
          <div className="overflow-hidden rounded-3xl shadow-lg">
            <iframe
              title="Mrizi i Zanave"
              src="https://www.google.com/maps?q=Mrizi+i+Zanave+Fishte+Lezhe&output=embed"
              className="h-[500px] w-full border-0"
              loading="lazy"
            />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Info({ icon: Icon, label, value }: { icon: typeof MapPin; label: string; value: string }) {
  return (
    <div className="flex items-start gap-4 rounded-2xl border border-border bg-card p-5">
      <span className="grid h-12 w-12 place-items-center rounded-full bg-primary/10 text-primary"><Icon className="h-5 w-5" /></span>
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="mt-1 font-medium">{value}</div>
      </div>
    </div>
  );
}
