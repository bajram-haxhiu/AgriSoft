import { createFileRoute } from "@tanstack/react-router";
import { rooms as seed, bookings, type Room } from "@/lib/mock-data";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, Pencil, Trash2 } from "lucide-react";

export const Route = createFileRoute("/dashboard/rooms")({ component: Page });

function Page() {
  const [list, setList] = useState<Room[]>(seed);
  const del = (id: string) => { setList((l) => l.filter((r) => r.id !== id)); toast.success("U fshi"); };
  const toggle = (id: string) => setList((l) => l.map((r) => r.id === id ? { ...r, available: !r.available } : r));

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl">Menaxho Dhomat</h2>
          <button onClick={() => toast("Forma e re (demo)")} className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground"><Plus className="h-3.5 w-3.5" /> Shto Dhomë</button>
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {list.map((r) => (
            <div key={r.id} className="overflow-hidden rounded-2xl border border-border">
              <img src={r.image} alt={r.name} className="aspect-[4/3] w-full object-cover" />
              <div className="p-4">
                <div className="flex items-start justify-between">
                  <div><div className="font-display text-lg">{r.name}</div><div className="text-xs text-muted-foreground">{r.type} · {r.capacity} pers.</div></div>
                  <div className="text-primary font-display text-lg">€{r.price}</div>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <button onClick={() => toggle(r.id)} className={`rounded-full px-3 py-1 text-[10px] font-semibold ${r.available ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"}`}>
                    {r.available ? "E disponueshme" : "E zënë"}
                  </button>
                  <div className="flex gap-1">
                    <button className="rounded-md border border-border p-1.5 hover:bg-secondary"><Pencil className="h-3.5 w-3.5" /></button>
                    <button onClick={() => del(r.id)} className="rounded-md border border-border p-1.5 hover:bg-destructive hover:text-destructive-foreground"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h2 className="font-display text-xl">Rezervimet e Dhomave</h2>
        <table className="mt-4 w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr><th className="py-2">Klient</th><th>Dhoma</th><th>Check-in</th><th>Check-out</th><th>Pers.</th><th>Statusi</th></tr>
          </thead>
          <tbody className="divide-y divide-border">
            {bookings.map((b) => (
              <tr key={b.id}>
                <td className="py-3 font-medium">{b.customer}</td>
                <td>{seed.find((r) => r.id === b.roomId)?.name}</td>
                <td>{b.checkIn}</td><td>{b.checkOut}</td><td>{b.guests}</td>
                <td><span className="rounded-full bg-primary/10 px-2 py-1 text-[10px] font-semibold uppercase text-primary">{b.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
