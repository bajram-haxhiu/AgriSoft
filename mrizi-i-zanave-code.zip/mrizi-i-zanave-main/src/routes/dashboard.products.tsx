import { createFileRoute } from "@tanstack/react-router";
import { products as seed, type Product } from "@/lib/mock-data";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2, Pencil } from "lucide-react";

export const Route = createFileRoute("/dashboard/products")({ component: Page });

function Page() {
  const [list, setList] = useState<Product[]>(seed);
  const del = (id: string) => { setList((l) => l.filter((p) => p.id !== id)); toast.success("Produkti u fshi"); };
  const sell = (id: string) => setList((l) => l.map((p) => p.id === id ? { ...p, stock: Math.max(0, p.stock - 1) } : p));

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl">Produkte Lokale</h2>
        <button onClick={() => toast("Forma e re (demo)")} className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground"><Plus className="h-3.5 w-3.5" /> Shto</button>
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {list.map((p) => (
          <div key={p.id} className="overflow-hidden rounded-2xl border border-border">
            <img src={p.image} alt={p.name} className="aspect-square w-full object-cover" />
            <div className="p-4">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">{p.category}</div>
              <div className="font-display text-lg">{p.name}</div>
              <div className="mt-1 flex items-center justify-between">
                <div className="font-display text-primary">€{p.price}</div>
                <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${p.stock < 15 ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary"}`}>Stoku: {p.stock}</span>
              </div>
              <div className="mt-3 flex gap-1">
                <button onClick={() => sell(p.id)} className="flex-1 rounded-md border border-border px-2 py-1 text-xs hover:bg-secondary">+1 shitje</button>
                <button className="rounded-md border border-border p-1.5"><Pencil className="h-3.5 w-3.5" /></button>
                <button onClick={() => del(p.id)} className="rounded-md border border-border p-1.5 hover:bg-destructive hover:text-destructive-foreground"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
