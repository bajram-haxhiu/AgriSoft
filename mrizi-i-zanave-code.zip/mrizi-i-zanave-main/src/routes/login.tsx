import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useAuth, demoLogins, type Role } from "@/lib/auth";
import { Navbar } from "@/components/site/Navbar";
import { Leaf } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  component: LoginPage,
  head: () => ({ meta: [{ title: "Hyr — AgriSoft Mrizi i Zanave" }] }),
});

function LoginPage() {
  const [tab, setTab] = useState<"customer" | "admin" | "staff">("customer");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useAuth();
  const nav = useNavigate();

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const role: Role = tab === "customer" ? "customer" : tab === "admin" ? "admin" : "receptionist";
    const u = login(email, password, role);
    toast.success(`Mirë se erdhe, ${u.name}!`);
    nav({ to: u.role === "customer" ? "/account" : "/dashboard" });
  };

  const quickLogin = (em: string, pw: string) => {
    const u = login(em, pw);
    toast.success(`Hyrje si ${u.role}`);
    nav({ to: u.role === "customer" ? "/account" : "/dashboard" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto grid max-w-7xl gap-12 px-4 py-16 lg:grid-cols-2 lg:px-8">
        <div className="rounded-3xl border border-border bg-card p-8 shadow-sm">
          <div className="flex items-center gap-2">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-primary text-primary-foreground"><Leaf className="h-4 w-4" /></span>
            <h1 className="font-display text-3xl">Hyr në AgriSoft</h1>
          </div>
          <div className="mt-6 inline-flex rounded-full bg-secondary p-1 text-xs font-semibold">
            {(["customer", "staff", "admin"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`rounded-full px-4 py-1.5 capitalize ${tab === t ? "bg-card shadow" : "text-muted-foreground"}`}>
                {t === "customer" ? "Klient" : t === "staff" ? "Staf" : "Admin"}
              </button>
            ))}
          </div>
          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <Field label="Email"><input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="input" placeholder="email@mrizi.al" /></Field>
            <Field label="Fjalëkalimi"><input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="input" placeholder="••••••••" /></Field>
            <button className="w-full rounded-full bg-primary py-3 text-sm font-semibold text-primary-foreground hover:opacity-90">Hyr</button>
          </form>
          <p className="mt-6 text-sm text-muted-foreground">
            Nuk ke llogari? <Link to="/register" className="font-semibold text-primary hover:underline">Regjistrohu</Link>
          </p>
        </div>

        <div className="rounded-3xl border border-border bg-secondary/50 p-8">
          <h2 className="font-display text-2xl">Llogari Demo</h2>
          <p className="mt-2 text-sm text-muted-foreground">Kliko për të hyrë me çdo rol — të dhënat ruhen lokalisht.</p>
          <ul className="mt-6 space-y-2">
            {demoLogins.map((d) => (
              <li key={d.email} className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4">
                <div className="text-sm">
                  <div className="font-semibold capitalize">{d.role}</div>
                  <div className="text-xs text-muted-foreground">{d.email} · {d.password}</div>
                </div>
                <button onClick={() => quickLogin(d.email, d.password)} className="rounded-full bg-primary px-4 py-1.5 text-xs font-semibold text-primary-foreground hover:opacity-90">
                  Hyr
                </button>
              </li>
            ))}
          </ul>
        </div>
      </main>
      <style>{`.input{width:100%;border-radius:.75rem;border:1px solid var(--input);background:var(--background);padding:.625rem .75rem;font-size:.875rem}`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}
