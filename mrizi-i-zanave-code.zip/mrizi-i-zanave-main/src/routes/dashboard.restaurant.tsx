import { createFileRoute } from "@tanstack/react-router";
import { menu, orders as seedOrders, type Order } from "@/lib/mock-data";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/restaurant")({ component: Page });

const statuses: Order["status"][] = ["pending", "preparing", "served", "paid"];

function Page() {
  const [orders, setOrders] = useState<Order[]>(seedOrders);
  const advance = (id: string) => setOrders((o) => o.map((x) => {
    if (x.id !== id) return x;
    const i = statuses.indexOf(x.status);
    const next = statuses[Math.min(i + 1, statuses.length - 1)];
    toast.success(`Porosia ${id} → ${next}`);
    return { ...x, status: next };
  }));

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h2 className="font-display text-xl">Menyja</h2>
        <ul className="mt-4 divide-y divide-border">
          {menu.map((m) => (
            <li key={m.id} className="flex items-center gap-3 py-3">
              <img src={m.image} alt={m.name} className="h-12 w-12 rounded-lg object-cover" />
              <div className="flex-1"><div className="font-medium">{m.name}</div><div className="text-xs text-muted-foreground">{m.category}</div></div>
              <div className="font-display text-primary">€{m.price}</div>
            </li>
          ))}
        </ul>
      </div>
      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h2 className="font-display text-xl">Porositë Aktive</h2>
        <ul className="mt-4 space-y-3">
          {orders.map((o) => {
            const total = o.items.reduce((s, i) => s + i.price * i.qty, 0);
            return (
              <li key={o.id} className="rounded-xl border border-border p-4">
                <div className="flex items-center justify-between">
                  <div className="font-semibold">{o.table} · #{o.id}</div>
                  <span className={`rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase ${o.status === "paid" ? "bg-primary/10 text-primary" : o.status === "served" ? "bg-accent/30" : o.status === "preparing" ? "bg-clay/20 text-clay" : "bg-muted text-muted-foreground"}`}>{o.status}</span>
                </div>
                <ul className="mt-2 text-xs text-muted-foreground">
                  {o.items.map((i, k) => <li key={k}>{i.qty}× {i.name} — €{i.price * i.qty}</li>)}
                </ul>
                <div className="mt-3 flex items-center justify-between">
                  <div className="font-display text-lg text-primary">€{total}</div>
                  <button onClick={() => advance(o.id)} className="rounded-full bg-primary px-4 py-1.5 text-xs font-semibold text-primary-foreground">Avanco</button>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
