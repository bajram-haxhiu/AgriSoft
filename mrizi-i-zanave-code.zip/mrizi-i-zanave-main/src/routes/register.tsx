import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { Navbar } from "@/components/site/Navbar";
import { Leaf } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/register")({
  component: RegisterPage,
  head: () => ({ meta: [{ title: "Regjistrohu — AgriSoft" }] }),
});

function RegisterPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { register } = useAuth();
  const nav = useNavigate();

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const u = register(name, email, password);
    toast.success(`Llogaria u krijua, ${u.name}!`);
    nav({ to: "/account" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-md px-4 py-16 lg:px-8">
        <div className="rounded-3xl border border-border bg-card p-8 shadow-sm">
          <div className="flex items-center gap-2">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-primary text-primary-foreground"><Leaf className="h-4 w-4" /></span>
            <h1 className="font-display text-3xl">Krijo Llogarinë</h1>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">Bashkohu me Mrizi i Zanave — rezervo dhe blej online.</p>
          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <Field label="Emri i plotë"><input required value={name} onChange={(e) => setName(e.target.value)} className="input" /></Field>
            <Field label="Email"><input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="input" /></Field>
            <Field label="Fjalëkalimi"><input required type="password" minLength={4} value={password} onChange={(e) => setPassword(e.target.value)} className="input" /></Field>
            <button className="w-full rounded-full bg-primary py-3 text-sm font-semibold text-primary-foreground hover:opacity-90">Regjistrohu</button>
          </form>
          <p className="mt-6 text-sm text-muted-foreground">Ke llogari? <Link to="/login" className="font-semibold text-primary hover:underline">Hyr</Link></p>
        </div>
      </main>
      <style>{`.input{width:100%;border-radius:.75rem;border:1px solid var(--input);background:var(--background);padding:.625rem .75rem;font-size:.875rem}`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}
