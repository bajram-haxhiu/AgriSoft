import { Link } from "@tanstack/react-router";
import { Leaf, Mail, MapPin, Phone } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border bg-sidebar text-sidebar-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 lg:grid-cols-4 lg:px-8">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground">
              <Leaf className="h-4 w-4" />
            </span>
            <div className="font-display text-xl">AgriSoft</div>
          </div>
          <p className="mt-4 text-sm text-sidebar-foreground/70">
            Platformë e integruar menaxhimi për Mrizi i Zanave — agroturizëm autentik shqiptar në Fishtë, Lezhë.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wider">Eksploro</h4>
          <ul className="mt-4 space-y-2 text-sm text-sidebar-foreground/70">
            <li><Link to="/rooms" className="hover:text-primary">Dhomat & Bujtinat</Link></li>
            <li><Link to="/restaurant" className="hover:text-primary">Restoranti</Link></li>
            <li><Link to="/shop" className="hover:text-primary">Produktet Lokale</Link></li>
            <li><Link to="/about" className="hover:text-primary">Rreth Nesh</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wider">Kontakt</h4>
          <ul className="mt-4 space-y-3 text-sm text-sidebar-foreground/70">
            <li className="flex gap-2"><MapPin className="h-4 w-4 mt-0.5" /> Fishtë, Lezhë, Shqipëri</li>
            <li className="flex gap-2"><Phone className="h-4 w-4 mt-0.5" /> +355 69 209 2298</li>
            <li className="flex gap-2"><Mail className="h-4 w-4 mt-0.5" /> info@mriziizanave.com</li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wider">Demo</h4>
          <p className="mt-4 text-sm text-sidebar-foreground/70">
            Projekt universitar — Analizë dhe Dizajn Software. Të dhënat janë demo lokale.
          </p>
          <Link to="/login" className="mt-4 inline-block rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground">
            Hyr në panel
          </Link>
        </div>
      </div>
      <div className="border-t border-sidebar-border py-5 text-center text-xs text-sidebar-foreground/50">
        © {new Date().getFullYear()} AgriSoft — Mrizi i Zanave. Të gjitha të drejtat e rezervuara.
      </div>
    </footer>
  );
}
