import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X, Leaf } from "lucide-react";
import { useAuth } from "@/lib/auth";

const links = [
  { to: "/", label: "Kreu" },
  { to: "/rooms", label: "Dhomat" },
  { to: "/restaurant", label: "Restoranti" },
  { to: "/shop", label: "Produktet" },
  { to: "/about", label: "Rreth Nesh" },
  { to: "/contact", label: "Kontakt" },
] as const;

export function Navbar() {
  const [open, setOpen] = useState(false);
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground">
            <Leaf className="h-4 w-4" />
          </span>
          <div className="leading-tight">
            <div className="font-display text-lg font-semibold">AgriSoft</div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Mrizi i Zanave</div>
          </div>
        </Link>

        <nav className="hidden items-center gap-7 lg:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="text-sm font-medium text-foreground/80 transition hover:text-primary"
              activeProps={{ className: "text-primary" }}
              activeOptions={{ exact: l.to === "/" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          {user ? (
            <Link
              to={user.role === "customer" ? "/account" : "/dashboard"}
              className="rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground transition hover:opacity-90"
            >
              {user.role === "customer" ? "Llogaria ime" : "Paneli"}
            </Link>
          ) : (
            <>
              <Link to="/login" className="text-sm font-medium hover:text-primary">Hyr</Link>
              <Link
                to="/restaurant"
                className="rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
              >
                Rezervo Tani
              </Link>
            </>
          )}
        </div>

        <button className="lg:hidden" onClick={() => setOpen((v) => !v)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <div className="border-t border-border bg-background lg:hidden">
          <nav className="flex flex-col px-4 py-3">
            {links.map((l) => (
              <Link key={l.to} to={l.to} className="py-3 text-sm font-medium" onClick={() => setOpen(false)}>
                {l.label}
              </Link>
            ))}
            <Link to="/login" className="py-3 text-sm font-medium" onClick={() => setOpen(false)}>Hyr</Link>
          </nav>
        </div>
      )}
    </header>
  );
}
